﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace szazig
{
    class Program
    {
        static int[] numbers = new int[100];
        static int left = 0;
        static int right = numbers.Length-1;
        static int sum = 0;
        static bool szal1kesz = false;
        static bool szal2kesz = false;
        static void FromLeft()
        {
            int lsum = 0;
                for (; left < right; left++)
                {
                    
                        lsum += numbers[left];
                        Console.WriteLine(numbers[left]);
                }
                lock (numbers)
                {
                    sum += lsum;
                }
            }

        static void FromRight()
        {
                int lsum = 0;
                for (; right > left; right--)
                {
                        lsum += numbers[right];
                        Console.WriteLine(numbers[right]);
                }
                lock (numbers)
                {
                    sum += lsum;
                }
        }
        static void Main(string[] args)
        {
            for (int i = 0; i < numbers.Length; i++)
                numbers[i] = i;
            Thread t1 = new Thread(FromLeft);
            Thread t2 = new Thread(FromRight);
            //t1.Priority = ThreadPriority.AboveNormal;
            //t2.Priority = ThreadPriority.Lowest;
            t1.Start();
            t2.Start();
            t1.Join();
            t2.Join();
            Console.WriteLine(sum);
            //FromLeft();
            //FromRight();
            Console.ReadKey();
        }
    }
}











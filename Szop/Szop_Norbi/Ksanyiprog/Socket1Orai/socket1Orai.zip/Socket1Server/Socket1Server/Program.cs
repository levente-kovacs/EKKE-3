﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Socket1Server
{
    class ClientComm
    {
        StreamWriter w=null;
        StreamReader r=null;
        TcpClient cl;
        public ClientComm(TcpClient client)
        {
            cl = client;
            w = new StreamWriter(cl.GetStream(), Encoding.UTF8);
            r = new StreamReader(cl.GetStream(), Encoding.UTF8);
        }

        public void Start()
        {
            
            w.WriteLine("Luke, Ich bin deine Vater");
            w.Flush();
            string command = r.ReadLine();
            while (command != "BYE")
            {
                string[] line = command.Split('|');
                switch (line[0].ToUpper())
                {
                    case "ADD": Add(int.Parse(line[1]), int.Parse(line[2])); break;
                    case "PRIMEK": Primes(int.Parse(line[1])); break;
                    case "FIBO": Fibonacci(int.Parse(line[1])); break;
                    default: w.WriteLine("ERR|Nincs ilyen művelet"); break;
                }
                w.Flush();
                command = r.ReadLine();
            }
        }
        void Add(int a, int b)
        {
            w.WriteLine("OK|{0}", a + b);
        }

        void Primes(int N)
        {
            w.WriteLine("OK*");
            for (int i = 2; i <= N; i++)
                if (Prime(i))
                    w.WriteLine(i);
            w.WriteLine("OK!");
        }

        static bool Prime(int num)
        {
            bool prim = true;
            for (int i = 2; i <= Math.Sqrt(num) && prim; i++)
                if (num % i == 0)
                    prim = false;
            return prim;
        }


        void Fibonacci(int N)
        {
            w.WriteLine("OK|8");
        }
    }

    class Program
    {
        static String IpAddre = "127.0.0.1";
        static int port = 12345;
        static void Main(string[] args)
        {
            IPAddress ip = IPAddress.Parse(IpAddre);
            TcpListener listener = new TcpListener(ip, port);
            listener.Start();
            while (true)
            {
                TcpClient client = listener.AcceptTcpClient();
                ClientComm cl = new ClientComm(client);
                Thread t = new Thread(cl.Start);
                t.Start();
            }
        }
    }
}

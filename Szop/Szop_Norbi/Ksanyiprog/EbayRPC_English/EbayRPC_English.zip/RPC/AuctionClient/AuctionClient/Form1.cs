﻿using Auction;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AuctionClient
{
    public partial class Form1 : Form
    {
        string id = null;
        IAukcion aukcion;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            IInstanceReq m = (IInstanceReq)Activator.GetObject(typeof(IInstanceReq), "tcp://127.0.0.1:8080/GetInstance");
            string id = m.instance_generate();
            aukcion = (IAukcion)Activator.GetObject(typeof(IAukcion), "tcp://127.0.0.1:8080/" + id);
            label8.Text = id;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            aukcion.login(textBox1.Text, textBox2.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            List<Product> result = aukcion.List();
            listBox1.Items.Clear();
            foreach (Product item in result)
            {
                string temp = "";
                temp = temp + item.Code + item.Name + item.Curr_price.ToString();
                listBox1.Items.Add(temp);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string result = aukcion.add(textBox3.Text, textBox4.Text, int.Parse(textBox5.Text));
            label8.Text = result;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string result = aukcion.Bid(textBox6.Text, int.Parse(textBox7.Text));
            label8.Text = result;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string result = aukcion.bye();
            label8.Text = result;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Auction
{
    public interface IInstanceReq
    {
        string instance_generate();
    }


    public interface IAukcion
    {
        bool login(string user, string passwd);
        string bye();
        string add(string name, string code, int price);
        List<Product> List();
        string Bid(string code, int price);
    }


    [Serializable]
    public class Product
    {
        string name, code, user = null;
        public string User
        {
            get { return user; }
            set { user = value; }
        }

        public string Code
        {
            get { return code; }
            set { code = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        int curr_price;

        public int Curr_price
        {
            get { return curr_price; }
            set { curr_price = value; }
        }
        public Product(string name, string code, int curr_price)
        {
            this.name = name; this.code = code; this.curr_price = curr_price;
        }
    }
}

﻿using Auction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;


namespace Auction_Implement
{
    public class InstanceReq : MarshalByRefObject, IInstanceReq
{
        public string instance_generate()
        {
            string id = Guid.NewGuid().ToString();
            RemotingConfiguration.RegisterWellKnownServiceType(typeof(Aukcio), id, WellKnownObjectMode.Singleton);
            return id;

        }

        public class Aukcio : MarshalByRefObject, IAukcion
        {
        public static List<Product> Product = new List<Product>();
        public string user = null;
        public bool login(string user, string jelszo)
        {
            this.user = user;
            return true;
        }
        public string bye()
        {
            return "Bye-bye";
        }
        public string add(string name, string Code, int price)
        {
            if (user == null)
            {
                return "Login, please!";
            }
            else
            {
                lock (Product)
                {
                    int i = 0;
                    for (i = 0; i < Product.Count && Product[i].Code != Code; i++) ;
                    if (i < Product.Count)
                    {
                        return "Already exists";
                    }
                    else
                    {
                        Product temp = new Product(name, Code, price);
                        Product.Add(temp);
                        return "OK";
                    }
                }
            }
        }
        public List<Product> List()
        {
            lock (Product)
            {
                return Product;
            }
        }
        public string Bid(string Code, int price)
        {
            if (user == null)
            {
                return "Login";
            }
            else
            {
                //Product t = null;
                lock (Product)
                {
                    int j = 0;
                    for (j = 0; j < Product.Count && Product[j].Code != Code; j++) ;
                    if (j >= Product.Count)
                    {
                        return "Invalid code";
                    }
                    else
                        if (Product[j].Curr_price < price)
                        {
                            Product[j].Curr_price = price;
                            Product[j].User = user;
                            return "OK";
                        }
                        else
                            return "Low price";
                }
            }
        }
    }
    }
}


﻿using Auction_Implement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Text;
using System.Threading.Tasks;


namespace AuctionHost
{
    class Program
    {
        static void Main(string[] args)
        {
            TcpChannel chan = new TcpChannel(8080);
            ChannelServices.RegisterChannel(chan, false);
            RemotingConfiguration.RegisterWellKnownServiceType(typeof(InstanceReq), "GetInstance", WellKnownObjectMode.SingleCall);
            Console.WriteLine("Instance have been created");
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProducerConsumer1
{
    class Program
    {
        public static List<int> buffer = new List<int>();
        public const int Size = 40;
        public const int numberOfPrimes = 400;

        static void Main(string[] args)
        {
            Producer pr = new Producer(ConsoleColor.Red);
            Consumer cr = new Consumer(ConsoleColor.Yellow);
            Thread t1 = new Thread(pr.Produce);
            Thread t2=new Thread(cr.Consume);
            //t1.Priority = ThreadPriority.Lowest;
            //t2.Priority = ThreadPriority.Highest;
            t1.Start();
            t2.Start();
            Console.ReadKey();
        }
    }
    class Producer
    {
        ConsoleColor cl;
        public Producer(ConsoleColor cl)
        {
            this.cl = cl;
        }

        bool Prime(int number)
        {
            bool Prim = true;
            for (int i = 2; i <= Math.Sqrt(number) && Prim; i++)
                if (number % i == 0)
                    Prim = false;
            return Prim;
        }
        public void Produce()
        {
            int PrimNumbers = 0;
            for (int i=1000;i<=100000 && PrimNumbers<Program.numberOfPrimes;i++)
           {
               if (Prime(i))
               {
                   lock (Program.buffer)
                   {
                       while (Program.Size == Program.buffer.Count)
                           Monitor.Wait(Program.buffer);
                       Program.buffer.Add(i);
                       Console.ForegroundColor = this.cl;
                       Console.WriteLine(i);
                       Monitor.Pulse(Program.buffer);
                   }
                  // Thread.Sleep(38);
                   PrimNumbers++;
               }
           }
        }
    }

    class Consumer
    {
        ConsoleColor cl;
        public Consumer (ConsoleColor cl)
        {
            this.cl = cl;
        }

        public void Consume()
        {
            for (int i = 0; i < Program.numberOfPrimes; i++)
            {
                lock (Program.buffer)
                {
                    while (Program.buffer.Count == 0)
                        Monitor.Wait(Program.buffer);
                    Console.ForegroundColor = this.cl;
                    Console.WriteLine(Program.buffer[0]);
                    Program.buffer.RemoveAt(0);
                    Monitor.Pulse(Program.buffer);
                }
                //Thread.Sleep(12);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace MatrixInThread
{
    class Program
    {
        const int N = 25; const int M = 80; const int K = 2000;
        static char[,] matrix = new char[N,M];
        static Random rn = new Random();

        static void Proc_X()
        {
            for (int i = 0; i < K; i++)
            {
                int x = rn.Next(N);
                int y = rn.Next(M);
                lock (matrix)
                {
                    if (matrix[x, y] != 'O')
                        matrix[x, y]='X';
                }
            }
        }

        static void Proc_O()
        {
            for (int i = 0; i < K; i++)
            {
                int x = rn.Next(N);
                int y = rn.Next(M);
                lock (matrix)
                {
                    if (matrix[x, y] != 'X')
                        matrix[x, y] = '0';
                }
            }
        }

        static void Main(string[] args)
        {
            Thread t1 = new Thread(Proc_X);
            Thread t2 = new Thread(Proc_O); t1.Priority = ThreadPriority.Lowest;
            t2.Priority = ThreadPriority.Highest;
            t2.Start(); t1.Start(); t1.Join(); t2.Join();
            //
            int numOfX = 0; int numOfO = 0;
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < M; j++)
                {
                    Console.Write(matrix[i, j]);
                    if (matrix[i, j] == 'X')
                        numOfX++;
                    else
                        if (matrix[i, j] == '0')
                            numOfO++;
                }
                Console.WriteLine();
            }
            Console.ReadKey();
            Console.WriteLine("Number of X: {0}, number of 0: {1}", numOfX, numOfO);
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Socket
{
    class Program
    {
        static void Main(string[] args)
        {
            //IPAddress, Port number, TcpClient, TcpListener and StreamReader, StreamWriter
            string ipaddress="127.0.0.1";
            IPAddress ip = IPAddress.Parse(ipaddress);
            TcpListener listener = new TcpListener(ip, 3000); 
            listener.Start();
            TcpClient client = listener.AcceptTcpClient();
            StreamWriter w = new StreamWriter(client.GetStream(), Encoding.UTF8);
            StreamReader r = new StreamReader(client.GetStream(), Encoding.UTF8);
            w.WriteLine("Server, 1.0");
            w.Flush();
            bool end = false;
            while (!end)
            {
                string[] command = r.ReadLine().Split('|');
                switch (command[0].ToUpper())
                {
                    case "DIVIDE":
                        if (int.Parse(command[2]) == 0)
                        {
                            w.WriteLine("OK!");
                            w.WriteLine("Division by zero");
                            w.WriteLine("OK*");
                        }
                        else
                            w.WriteLine("{0}", float.Parse(command[1]) / 
                                float.Parse(command[2]));
                        break;
                    case "BYE":
                        w.WriteLine("BYE"); end=true;break;
                    default:
                        w.WriteLine("Unknown command");break;
                }
                w.Flush();
            }
        }
    }
}

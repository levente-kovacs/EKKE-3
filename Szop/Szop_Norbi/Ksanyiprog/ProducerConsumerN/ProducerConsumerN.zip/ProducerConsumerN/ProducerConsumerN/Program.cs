﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ProducerConsumerN
{
        class Supervisor
        {
            static List<int> puffer = new List<int>();
            static int BuffSize = 50;
            static int NumberOfProducers = 0;
            static int NumberOfConsumers = 0;
            static bool ProducersStopped = false;
            static bool ConsumersStopped = false;

            public static void ProducersStarts()
            {
                lock (typeof(Supervisor))
                {
                    NumberOfProducers++;
                }
            }

            public static void ConsumerStarts()
            {
                lock (typeof(Supervisor))
                {
                    NumberOfConsumers++;
                }
            }

            public static void ProducerStops()
            {
                lock (typeof(Supervisor))
                {
                    NumberOfProducers--; //A 3. hiba Látszik, h nem áll le, tehát vkik alszanak, nincs aki felébressze őket. Ezért!
                }
                if (NumberOfProducers <= 0)
                {
                    ProducersStopped = true;
                }
                lock (puffer)
                {
                    Monitor.PulseAll(puffer);  //A 2. hiba lockolni nem kell??????  De bizony kell, nézzük meg, ha nincs lock, mi történik
                }
            }
            public static void ConsumerStops()
            {
                lock (typeof(Supervisor))
                {
                    NumberOfConsumers--;
                }
                if (NumberOfConsumers <= 0)
                {
                    ConsumersStopped = true; Console.WriteLine("Consumers stopped");
                }
                lock (puffer)
                {
                    Monitor.PulseAll(puffer);  //A 2. hiba!!!! lockolni nem kell??????  
                }
            }

            public static void Produce(int number)
            {
                lock (Supervisor.puffer)
                {
                    while (BuffSize <= puffer.Count)
                    {
                        if (!ConsumersStopped)
                            Monitor.Wait(puffer);
                        else
                            throw new Exception("Never reaches");  //itt dob kivételt!  Az első hiba. Miért is? Mert ezt az else-be kell írni!!
                    }
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine(number);
                    puffer.Add(number);
                    Monitor.PulseAll(puffer);
                }
            }

            public static int Consume()
            {
                int num;
                lock (puffer)
                {
                    while (puffer.Count <= 0)
                    {
                        if (ProducersStopped)
                            throw new Exception("No more producer");
                        Monitor.Wait(puffer);
                    }
                    num = puffer[0];
                    puffer.RemoveAt(0);
                    Monitor.PulseAll(puffer);
                }
                return num;
            }
        }

        class Producer
        {
            int start; int ende;
            public Producer(int from, int until)
            {
                start = from; ende = until;
            }

            public void Make()
            {
                Supervisor.ProducersStarts();
                for (int i = start; i <= ende; i++)
                    if (Prime(i))
                        Supervisor.Produce(i);
                Supervisor.ProducerStops(); //Console.WriteLine("1 termelő leállít"); Ez segít a debuggolásban. 
            }
            bool Prime(int num)
            {
                bool prim = true;
                for (int i = 2; i <= Math.Sqrt(num) && prim; i++)
                    if (num % i == 0)
                        prim = false;
                return prim;
            }
        }

        class Consumer
        {
            ConsoleColor c;
            public Consumer(ConsoleColor pc)
            {
                c = pc;
            }
            public void Consume()
            {
                Supervisor.ConsumerStarts();
                while (true)
                {
                    try
                    {
                        int temp = Supervisor.Consume();
                        lock (typeof(Program))
                        {
                            Console.ForegroundColor = c;
                            Console.WriteLine(temp);
                        }
                    }
                    catch (Exception e)
                    { break; }
                }
                Console.WriteLine("There's no more producer, 1 consumer stopped");
                Supervisor.ConsumerStops();
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                Producer p1 = new Producer(1000, 2000);
                Producer p2 = new Producer(2001, 3000);
                Producer p3 = new Producer(3001, 4000);
                Producer p4 = new Producer(4001, 5000);
                Thread t1 = new Thread(p1.Make);
                Thread t2 = new Thread(p2.Make);
                Thread t3 = new Thread(p3.Make);
                Thread t4 = new Thread(p4.Make);
                Consumer c1 = new Consumer(ConsoleColor.Blue);
                Consumer c2 = new Consumer(ConsoleColor.Yellow);
                Thread t5 = new Thread(c1.Consume);
                Thread t6 = new Thread(c2.Consume);
                t1.Start(); t2.Start(); t3.Start(); t4.Start();
                t5.Start(); t6.Start();
                Console.ReadKey();
            }
        }
    }

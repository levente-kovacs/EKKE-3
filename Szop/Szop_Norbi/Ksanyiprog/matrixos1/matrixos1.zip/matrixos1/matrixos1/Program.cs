﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace matrixos1
{
    class Program
    {
        const int N = 25; const int M = 80;
        static char[,] matrix = new char[N, M];
        static Random rn = new Random();
        static void Proc_X()
        {

            for (int i = 0; i < 2000; i++)
            {
                int x = rn.Next(0, 25);
                int y = rn.Next(0, 80);
                lock (matrix)
                {
                    if (matrix[x, y] != 'O')
                        matrix[x, y] = 'X';
                }
            }
        }

        static void Proc_O()
        {
            for (int i = 0; i < 2000; i++)
            {
                int x = rn.Next(0, 25);
                int y = rn.Next(0, 80);
                lock (matrix)
                {
                    if (matrix[x, y] != 'X')
                        matrix[x, y] = 'O';
                }

            }
        }


        static void Main(string[] args)
        {
            Thread t1 = new Thread(Proc_X);
            Thread t2 = new Thread(Proc_O); t2.Priority = ThreadPriority.Highest;
            t1.Priority = ThreadPriority.Lowest;
            t1.Start(); t2.Start();
            t1.Join(); t2.Join(); int numOfX = 0; int numOfY = 0;
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < M; j++)
                {
                    Console.Write(matrix[i, j]);
                    if (matrix[i, j] == 'X')
                        numOfX++;
                    else
                        numOfY++;
                }
                Console.WriteLine();
            }
            Console.WriteLine("X: {0}, Y:{1}", numOfX, numOfY);
            Console.ReadKey();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rest_API_Kliens
{
    
    public partial class Token
    {

        public string token { get; set; }        
       

    }
}

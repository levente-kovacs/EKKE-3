admin jogosultsággal rendelkező felhasználók:

2db:
felhasználónév: admin
jelszó: admin

felhasználónév: adminteszt
jelszó: teszt

Átalános jogosultsággal rendelkező felhasználó:

1db

felhasználónév: felhasznalo
jelszó: felhasznalo